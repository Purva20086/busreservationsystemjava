let buses=[], currentBus=null, selectedSeats=[], currentBooking=null;

document.addEventListener('DOMContentLoaded',()=>{document.getElementById('date').value=new Date().toISOString().slice(0,10); searchBuses();});

async function api(url, options={}) {
    const r=await fetch(url, options);
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.message||'Something went wrong');
    return data;
}
function hidePages(){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'))}
function showHome(){hidePages();document.getElementById('home').classList.remove('hidden');searchBuses()}
function showBookings(){hidePages();document.getElementById('bookingsPage').classList.remove('hidden');loadBookings()}
function showSeats(){hidePages();document.getElementById('seatPage').classList.remove('hidden')}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2500)}

async function searchBuses(){
    const s=document.getElementById('source').value,d=document.getElementById('destination').value;
    buses=await api(`/api/buses?source=${encodeURIComponent(s)}&destination=${encodeURIComponent(d)}`);
    document.getElementById('resultCount').textContent=`${buses.length} bus${buses.length!==1?'es':''} available for your route`;
    renderBuses();
}
function renderBuses(){
    const el=document.getElementById('busList');
    if(!buses.length){el.innerHTML='<div class="empty">No buses found for this route. Try another destination.</div>';return}
    el.innerHTML=buses.map(b=>`<div class="bus-card">
      <div class="bus-main"><div class="bus-icon">🚌</div><div><div class="bus-name">${b.name}</div><div class="bus-meta">${b.type} • ${b.totalSeats-b.bookedSeats.length} seats available</div></div></div>
      <div><div class="route">${b.source} → ${b.destination}</div><div class="time">${b.departure} — ${b.arrival}</div></div>
      <div class="bus-price"><div class="price">₹${b.price}</div><div class="available-count">per seat</div><button class="primary" style="margin-top:10px;padding:10px 14px" onclick="selectBus(${b.id})">View Seats</button></div>
    </div>`).join('');
}
async function selectBus(id){
    currentBus=await api(`/api/buses/${id}`);selectedSeats=[];
    document.getElementById('seatBusName').textContent=currentBus.name;
    document.getElementById('seatRoute').textContent=`${currentBus.source} → ${currentBus.destination} • ${currentBus.departure}`;
    document.getElementById('seatPrice').textContent=`₹${currentBus.price} / seat`;
    renderSeats();showSeats();
}
function renderSeats(){
    const grid=document.getElementById('seatGrid');
    grid.innerHTML=Array.from({length:currentBus.totalSeats},(_,i)=>{
        const n=i+1,b=currentBus.bookedSeats.includes(n),s=selectedSeats.includes(n);
        return `<button class="seat ${b?'booked':s?'selected':'available'}" ${b?'disabled':''} onclick="toggleSeat(${n})">${n}</button>`;
    }).join('');
    const total=selectedSeats.length*currentBus.price;
    document.getElementById('total').textContent=`₹${total}`;
    document.getElementById('selectedSummary').innerHTML=selectedSeats.length?
      `<div class="summary-seats"><strong>Seats:</strong> ${selectedSeats.join(', ')}<br><strong>${selectedSeats.length}</strong> passenger${selectedSeats.length>1?'s':''}</div>`:'Select one or more seats.';
}
function toggleSeat(n){
    selectedSeats=selectedSeats.includes(n)?selectedSeats.filter(x=>x!==n):[...selectedSeats,n];
    renderSeats();
}
function openPassenger(){
    if(!selectedSeats.length){toast('Please select at least one seat.');return}
    document.getElementById('tripMini').innerHTML=`<h3>${currentBus.name}</h3><p>${currentBus.source} → ${currentBus.destination}<br>${currentBus.departure} — ${currentBus.arrival}</p><p><strong>Seats:</strong> ${selectedSeats.join(', ')}</p><p><strong>Total:</strong> ₹${selectedSeats.length*currentBus.price}</p>`;
    hidePages();document.getElementById('passengerPage').classList.remove('hidden');
}
async function confirmBooking(){
    const name=document.getElementById('name').value.trim(),email=document.getElementById('email').value.trim(),phone=document.getElementById('phone').value.trim();
    if(!name||!email||!phone){toast('Please fill in all passenger details.');return}
    try{
        currentBooking=await api('/api/bookings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({busId:currentBus.id,name,email,phone,seats:selectedSeats})});
        document.getElementById('ticket').innerHTML=`<div class="ticket-row"><span>Booking ID</span><strong>${currentBooking.bookingId}</strong></div><div class="ticket-row"><span>Passenger</span><strong>${currentBooking.passengerName}</strong></div><div class="ticket-row"><span>Journey</span><strong>${currentBooking.source} → ${currentBooking.destination}</strong></div><div class="ticket-row"><span>Seats</span><strong>${currentBooking.seats.join(', ')}</strong></div><div class="ticket-row"><span>Amount</span><strong>₹${currentBooking.amount}</strong></div>`;
        hidePages();document.getElementById('successPage').classList.remove('hidden');
    }catch(e){toast(e.message);selectBus(currentBus.id)}
}
async function loadBookings(){
    const list=await api('/api/bookings'),el=document.getElementById('bookingsList');
    if(!list.length){el.innerHTML='<div class="empty">No bookings yet. Your reservations will appear here.</div>';return}
    el.innerHTML=list.map(b=>`<div class="booking-card"><div><h3>${b.busName} <span style="font-size:11px;color:#5b5cf0">#${b.bookingId}</span></h3><p>${b.source} → ${b.destination} • Seats ${b.seats.join(', ')}</p><p>${b.passengerName} • ₹${b.amount}</p></div><button class="cancel" onclick="cancelBooking('${b.bookingId}')">Cancel</button></div>`).join('');
}
async function cancelBooking(id){
    if(!confirm('Cancel this booking?')) return;
    const r=await api(`/api/bookings/${id}`,{method:'DELETE'});
    toast(r.success?'Booking cancelled.':'Booking not found.');
    loadBookings();
}
