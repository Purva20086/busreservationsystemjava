package com.example.busreservation.controller;

import com.example.busreservation.model.Bus;
import com.example.busreservation.service.BusService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/buses")
@CrossOrigin
public class BusController {
    private final BusService busService;

    public BusController(BusService busService) {
        this.busService = busService;
    }

    @GetMapping
    public List<Bus> search(@RequestParam(required = false) String source,
                            @RequestParam(required = false) String destination) {
        return busService.search(source, destination);
    }

    @GetMapping("/{id}")
    public Bus get(@PathVariable Long id) {
        Bus bus = busService.get(id);
        if (bus == null) throw new RuntimeException("Bus not found");
        return bus;
    }
}
