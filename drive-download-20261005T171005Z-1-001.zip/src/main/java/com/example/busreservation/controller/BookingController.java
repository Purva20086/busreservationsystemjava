package com.example.busreservation.controller;

import com.example.busreservation.model.Booking;
import com.example.busreservation.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin
public class BookingController {
    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public List<Booking> all() {
        return bookingService.all();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Booking create(@RequestBody Map<String, Object> body) {
        Long busId = Long.valueOf(body.get("busId").toString());
        String name = body.get("name").toString();
        String email = body.get("email").toString();
        String phone = body.get("phone").toString();
        @SuppressWarnings("unchecked")
        List<Integer> seats = ((List<?>) body.get("seats")).stream()
                .map(v -> Integer.valueOf(v.toString())).toList();
        return bookingService.create(busId, name, email, phone, seats);
    }

    @DeleteMapping("/{id}")
    public Map<String, Object> cancel(@PathVariable String id) {
        return Map.of("success", bookingService.cancel(id));
    }
}
