package com.example.busreservation.model;

import java.util.List;

public class Booking {
    private String bookingId;
    private Long busId;
    private String busName;
    private String source;
    private String destination;
    private String passengerName;
    private String email;
    private String phone;
    private List<Integer> seats;
    private double amount;

    public Booking() {}

    public Booking(String bookingId, Long busId, String busName, String source, String destination,
                   String passengerName, String email, String phone, List<Integer> seats, double amount) {
        this.bookingId = bookingId;
        this.busId = busId;
        this.busName = busName;
        this.source = source;
        this.destination = destination;
        this.passengerName = passengerName;
        this.email = email;
        this.phone = phone;
        this.seats = seats;
        this.amount = amount;
    }

    public String getBookingId() { return bookingId; }
    public Long getBusId() { return busId; }
    public String getBusName() { return busName; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public String getPassengerName() { return passengerName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public List<Integer> getSeats() { return seats; }
    public double getAmount() { return amount; }
}
