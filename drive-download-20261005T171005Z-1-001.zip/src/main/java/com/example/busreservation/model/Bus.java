package com.example.busreservation.model;

import java.util.ArrayList;
import java.util.List;

public class Bus {
    private Long id;
    private String name;
    private String source;
    private String destination;
    private String departure;
    private String arrival;
    private String type;
    private int totalSeats;
    private double price;
    private List<Integer> bookedSeats = new ArrayList<>();

    public Bus() {}

    public Bus(Long id, String name, String source, String destination, String departure,
               String arrival, String type, int totalSeats, double price) {
        this.id = id;
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.departure = departure;
        this.arrival = arrival;
        this.type = type;
        this.totalSeats = totalSeats;
        this.price = price;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public String getDeparture() { return departure; }
    public void setDeparture(String departure) { this.departure = departure; }
    public String getArrival() { return arrival; }
    public void setArrival(String arrival) { this.arrival = arrival; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public List<Integer> getBookedSeats() { return bookedSeats; }
    public void setBookedSeats(List<Integer> bookedSeats) { this.bookedSeats = bookedSeats; }
}
